Acme Dashboard deployment package.
Built for the upload demo.
